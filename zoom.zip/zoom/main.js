const img = document.querySelector('.img');
const lupa = document.querySelector('.lupa');
const zoom = document.querySelector('.zoom');
const range = document.querySelector('input');
const h1 = document.querySelector('h1');

let x = 3;
let slider = ['1.jpg','2.png','3.png','4.png','5.png','6.png','7.jfif'];
let names = ['Էլբակյան կրթահամալիր','Bill Gates (Microsoft)','Steve Jobs (Apple)','Mark Zuckerberg (Meta)','Jeff Bezos (Amazon)','Elon Musk (Tesla)','Brendan Eich (JS)']
range.max = slider.length-1;
range.oninput = () => {
    img.style.backgroundImage = `url(${slider[range.value]})`;
    zoom.style.backgroundImage = `url(${slider[range.value]})`;
    h1.textContent = names[range.value];
}

x2.onclick = () => {
    x = 3;
    zoom.style.backgroundSize = '500%';
    lupa.style = 'width: 100px; height: 100px; --i: 85px; --x: 112px; --y: 75px';
}
x3.onclick = () => {
    x = 4.5;
    zoom.style.backgroundSize = '750%'; 
    lupa.style = 'width: 66px; height: 66px; --i: 60px; --x: 73px; --y: 48px';
}

x5.onclick = () => {
    x = 6;
    zoom.style.backgroundSize = '1000%'; 
    lupa.style = 'width: 50px; height: 50px; --i: 48px; --x: 54px; --y: 37px';
}



img.onmouseover = () => {
    img.onmousemove = (e) => {
        lupa.style.top = (e.pageY - lupa.offsetHeight/2) + 'px';
        lupa.style.left = (e.pageX - lupa.offsetWidth/2) + 'px';
        
        zoom.style.backgroundPosition = `${(-e.offsetX + lupa.offsetWidth/2)*x}px ${(-e.offsetY + lupa.offsetHeight/2)*x}px`;
    }
}

